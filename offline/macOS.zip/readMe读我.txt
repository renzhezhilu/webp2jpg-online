

--------------------------------- 中文 --------------------------------------
https://renzhezhilu.github.io/webp2jpg-online 
webp2jpg-online v3.0 离线版说明
1.请使用谷歌浏览器打开。
2.修改文件名会导致页面错误。（convert.html 图片转换 & splicing.html 图片拼接）
3.第一次打开需要加载，加载完毕后无需网络也可使用。


---------------------------------- English ----------------------------------
https://renzhezhilu.github.io/webp2jpg-online 
webp2jpg-online v3.0 offline version description
1. Please use Google Chrome to open.
2. Modifying the file name will cause a page fault.(convert.html & splicing.html)
3. It needs to be loaded when it is opened for the first time. After loading, it can be used without a network.
